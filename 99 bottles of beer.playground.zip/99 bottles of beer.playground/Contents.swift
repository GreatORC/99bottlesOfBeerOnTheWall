import UIKit

func beerSong(forBottlesOfBeer maxBottleNumber : Int) -> String {
    var lyricString = ""
    if maxBottleNumber > 1 {
        for bottleNumber in (2...maxBottleNumber).reversed() {
            lyricString += "\(bottleNumber) bottles of beer on the wall, \(bottleNumber) bottles of beer.\nTake one down and pass it around, \(bottleNumber - 1) \(bottleNumber > 2 ? "bottles" : "bottle") of beer on the wall.\n\n"
        }
    }
    if maxBottleNumber > 0 {
        lyricString += "1 bottle of beer on the wall, 1 bottle of beer.\nTake it down and pass it around, no bottles of beer on the wall.\n\n"
    }
    lyricString += "No bottles of beer on the wall, no bottles of beer.\nGo to store and buy some more, \(maxBottleNumber) bottles of beer on the wall.\n\n"
    return lyricString
}

print(beerSong(forBottlesOfBeer: 2))

